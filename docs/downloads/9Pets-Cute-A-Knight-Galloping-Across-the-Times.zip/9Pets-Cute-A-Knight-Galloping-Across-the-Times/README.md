# 9Pets-Cute-A-Knight-Galloping-Across-the-Times

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300703.
Skin: Galloping Across the Times.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_300703_wxk.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_300703_wxk
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
