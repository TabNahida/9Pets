# 9Pets-Ms-Stranger

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 314701.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/314701.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_314701_wmz
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_314701_wmz

Install by copying the package folder contents into your Codex pets directory.
