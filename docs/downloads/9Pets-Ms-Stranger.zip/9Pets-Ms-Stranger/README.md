# 9Pets-Ms-Stranger

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official art atlas; Live2D path mapped.
Official asset id: 314701.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/handbookheroicon/314701.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_314701_wmz
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/314701_wmz

Install by copying the package folder contents into your Codex pets directory.
