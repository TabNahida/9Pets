# 9Pets-Cute-Marsha

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312701.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_312701_mes.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_312701_mes
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a3_312701_mes

Install by copying the package folder contents into your Codex pets directory.
