# 9Pets-Cute-Horropedia-A-Daoist-s-Madness

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306103.
Skin: A Daoist's Madness.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_306103_kbt.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_306103_kbt
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_306103_kbt

Install by copying the package folder contents into your Codex pets directory.
