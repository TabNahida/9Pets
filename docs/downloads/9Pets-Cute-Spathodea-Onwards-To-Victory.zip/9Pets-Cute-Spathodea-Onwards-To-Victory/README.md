# 9Pets-Cute-Spathodea-Onwards-To-Victory

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307303.
Skin: Onwards, To Victory!.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_307303_krd.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_307303_krd
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a0_307303_kerandian

Install by copying the package folder contents into your Codex pets directory.
