# 9Pets-Cute-Medicine-Pocket

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304701.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304701_tumaoshoudai.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304701_tumaoshoudai
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/304701_tumaoshoudai

Install by copying the package folder contents into your Codex pets directory.
