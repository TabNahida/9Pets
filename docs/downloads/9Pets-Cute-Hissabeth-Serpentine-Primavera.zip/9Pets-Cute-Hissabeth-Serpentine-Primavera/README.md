# 9Pets-Cute-Hissabeth-Serpentine-Primavera

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311603.
Skin: Serpentine Primavera.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_311603_lzl.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_311603_lzl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/s01_311603_lzl

Install by copying the package folder contents into your Codex pets directory.
