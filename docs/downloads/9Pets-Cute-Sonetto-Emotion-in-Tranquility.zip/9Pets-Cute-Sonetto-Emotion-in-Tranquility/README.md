# 9Pets-Cute-Sonetto-Emotion-in-Tranquility

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302304.
Skin: Emotion in Tranquility.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_302304_sshs.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_302304_sshs
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_302304_sshs

Install by copying the package folder contents into your Codex pets directory.
