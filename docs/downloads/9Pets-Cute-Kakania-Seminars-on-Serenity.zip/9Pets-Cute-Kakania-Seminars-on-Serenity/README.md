# 9Pets-Cute-Kakania-Seminars-on-Serenity

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308003.
Skin: Seminars on Serenity.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_308003_kkny.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_308003_kkny
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a4_308003_kakaniya

Install by copying the package folder contents into your Codex pets directory.
