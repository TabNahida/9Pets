# 9Pets-Cute-Willow-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310401.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_310401_ddg.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_310401_ddg
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a3_310401_ddg

Install by copying the package folder contents into your Codex pets directory.
