# 9Pets-Cute-Getian-Herald-of-Horus

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308404.
Skin: Herald of Horus.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_308404_gt.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_308404_gt
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a3_308404_gt

Install by copying the package folder contents into your Codex pets directory.
