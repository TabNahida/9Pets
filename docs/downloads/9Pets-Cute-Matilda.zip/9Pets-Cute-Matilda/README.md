# 9Pets-Cute-Matilda

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304101.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304101_madierda.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304101_madierda
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/304101_madierda

Install by copying the package folder contents into your Codex pets directory.
