# 9Pets-Cute-Nick-Bottom

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300501.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300501_nike.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300501_nike
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
