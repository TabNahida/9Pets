# 9Pets-Ms-NewBabel

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Source URL: https://re.bluepoch.com/home/img/role/1m.png

Install by copying the package folder contents into your Codex pets directory.
