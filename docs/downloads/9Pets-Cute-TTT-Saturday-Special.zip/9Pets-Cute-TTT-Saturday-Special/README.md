# 9Pets-Cute-TTT-Saturday-Special

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303303.
Skin: Saturday Special.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_303303_ttt.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_303303_ttt
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
