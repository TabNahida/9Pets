# 9Pets-Cute-Eternity-Lady-of-the-Evernight

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305102.
Skin: Lady of the Evernight.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305102_wennifuleide.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305102_wennifuleide
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/305102_wennifuleide

Install by copying the package folder contents into your Codex pets directory.
