# 9Pets-Bkornblume

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Spine motion capture.
Official asset id: 302001.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/302001.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302001_bolinyidong
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
