# 9Pets-Cute-Mondlicht-Silver-Schirm

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302603.
Skin: Silver Schirm.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_302603_hdp.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_302603_hdp
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
