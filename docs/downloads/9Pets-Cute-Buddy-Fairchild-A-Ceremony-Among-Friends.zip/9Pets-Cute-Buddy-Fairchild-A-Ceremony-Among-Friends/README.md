# 9Pets-Cute-Buddy-Fairchild-A-Ceremony-Among-Friends

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311502.
Skin: A Ceremony Among Friends.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_311502_jjsg.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_311502_jjsg
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a8_311502_jjsg

Install by copying the package folder contents into your Codex pets directory.
