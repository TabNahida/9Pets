# 9Pets-Cute-Eagle-Weekend-Excursion

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300604.
Skin: Weekend Excursion.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_300604_xcqe.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_300604_xcqe
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
