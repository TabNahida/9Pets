# 9Pets-Cute-Noire-The-Trapped-Trapmaster

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311103.
Skin: The Trapped Trapmaster.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_311103_flsd.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_311103_flsd
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_311103_flsd

Install by copying the package folder contents into your Codex pets directory.
