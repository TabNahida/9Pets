# 9Pets-Cute-Pickles-An-Indigo-Fluff

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306302.
Skin: An Indigo Fluff.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306302_pikelesi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306302_pikelesi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306302_pikelesi

Install by copying the package folder contents into your Codex pets directory.
