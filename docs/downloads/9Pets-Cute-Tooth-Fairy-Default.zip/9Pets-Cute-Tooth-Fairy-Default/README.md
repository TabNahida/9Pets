# 9Pets-Cute-Tooth-Fairy-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305301.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305301_yaxian.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305301_yaxian
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/305301_yaxian

Install by copying the package folder contents into your Codex pets directory.
