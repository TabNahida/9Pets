# 9Pets-Cute-Beryl-The-Flowing-Stream-s-Luster

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 313402.
Skin: The Flowing Stream's Luster.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_313402_ble.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_313402_ble
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a2_313402_ble

Install by copying the package folder contents into your Codex pets directory.
