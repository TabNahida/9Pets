# 9Pets-Cute-Nautika-Behind-the-Unknown

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312002.
Skin: Behind the "Unknown".
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_312002_ndk.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_312002_ndk
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a8_312002_ndk

Install by copying the package folder contents into your Codex pets directory.
