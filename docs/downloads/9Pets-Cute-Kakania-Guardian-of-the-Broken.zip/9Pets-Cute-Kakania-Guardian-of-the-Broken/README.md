# 9Pets-Cute-Kakania-Guardian-of-the-Broken

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308004.
Skin: Guardian of the Broken.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_308004_kkny.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_308004_kkny
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a2_308004_kkny

Install by copying the package folder contents into your Codex pets directory.
