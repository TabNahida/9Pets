# 9Pets-Cute-Druvis-III

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300301.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300301_hujisheng.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300301_hujisheng
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/300301_hujisheng

Install by copying the package folder contents into your Codex pets directory.
