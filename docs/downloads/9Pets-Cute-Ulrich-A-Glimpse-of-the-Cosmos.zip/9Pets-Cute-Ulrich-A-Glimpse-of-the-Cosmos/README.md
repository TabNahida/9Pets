# 9Pets-Cute-Ulrich-A-Glimpse-of-the-Cosmos

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310703.
Skin: A Glimpse of the Cosmos.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_310703_welx.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_310703_welx
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a8_310703_welx

Install by copying the package folder contents into your Codex pets directory.
