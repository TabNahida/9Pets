# 9Pets-Cute-Igor

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309201.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_309201_yge.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_309201_yge
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a3_309201_yge

Install by copying the package folder contents into your Codex pets directory.
