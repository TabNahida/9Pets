# 9Pets-Cute-Sotheby-The-Red-Thread-of-Fate

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300904.
Skin: The Red Thread of Fate.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_300904_sfb.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_300904_sfb
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a5_300904_sfb

Install by copying the package folder contents into your Codex pets directory.
