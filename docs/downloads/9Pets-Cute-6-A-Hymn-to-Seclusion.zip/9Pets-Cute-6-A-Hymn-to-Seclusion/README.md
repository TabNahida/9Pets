# 9Pets-Cute-6-A-Hymn-to-Seclusion

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307905.
Skin: A Hymn to Seclusion.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_307905_6.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_307905_6
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_307905_6

Install by copying the package folder contents into your Codex pets directory.
