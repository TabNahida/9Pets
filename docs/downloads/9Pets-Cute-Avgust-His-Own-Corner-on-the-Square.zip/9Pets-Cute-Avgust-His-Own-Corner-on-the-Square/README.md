# 9Pets-Cute-Avgust-His-Own-Corner-on-the-Square

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307802.
Skin: His Own Corner on the Square.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_307802_afuxiwei.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_307802_afuxiwei
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a8_307802_afuxiwei

Install by copying the package folder contents into your Codex pets directory.
