# 9Pets-Cute-37-Down-in-the-Grotto

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306604.
Skin: Down in the Grotto.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_306604_37.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_306604_37
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a2_306604_37

Install by copying the package folder contents into your Codex pets directory.
