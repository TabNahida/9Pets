# 9Pets-Cute-White-Rum-Big-World-in-a-Small-Bottle

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310102.
Skin: Big World in a Small Bottle.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_310102_bailangmu.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_310102_bailangmu
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
