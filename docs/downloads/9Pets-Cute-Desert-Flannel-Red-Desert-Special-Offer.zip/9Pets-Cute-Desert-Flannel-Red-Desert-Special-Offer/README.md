# 9Pets-Cute-Desert-Flannel-Red-Desert-Special-Offer

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307502.
Skin: Red Desert Special Offer.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_307502_shasirong.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_307502_shasirong
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a5_307502_shasirong

Install by copying the package folder contents into your Codex pets directory.
