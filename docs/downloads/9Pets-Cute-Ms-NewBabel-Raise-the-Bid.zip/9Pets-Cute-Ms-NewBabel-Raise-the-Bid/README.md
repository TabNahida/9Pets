# 9Pets-Cute-Ms-NewBabel-Raise-the-Bid

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305203.
Skin: Raise the Bid.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_305203_xbbt.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_305203_xbbt
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a4_305203_xbbt

Install by copying the package folder contents into your Codex pets directory.
