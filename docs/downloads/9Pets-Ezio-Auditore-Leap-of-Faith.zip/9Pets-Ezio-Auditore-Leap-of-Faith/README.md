# 9Pets-Ezio-Auditore-Leap-of-Faith

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 312302.
Skin: Leap of Faith.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/312302.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_312302_ajaadtl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/s01_312302_aja

Install by copying the package folder contents into your Codex pets directory.
