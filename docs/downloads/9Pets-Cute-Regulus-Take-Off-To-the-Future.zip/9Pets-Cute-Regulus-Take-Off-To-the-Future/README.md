# 9Pets-Cute-Regulus-Take-Off-To-the-Future

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302504.
Skin: Take Off! To the Future.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_302504_xt.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_302504_xt
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_302504_xingti

Install by copying the package folder contents into your Codex pets directory.
