# 9Pets-Cute-Barbara-A-Meadow-in-Her-Dreams

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309902.
Skin: A Meadow in Her Dreams.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_309902_syg.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_309902_syg
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a1_309902_syg

Install by copying the package folder contents into your Codex pets directory.
