# 9Pets-Cute-Ms-Moissan-Outside-the-Church

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304403.
Skin: Outside the Church.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_304403_mosangnvshi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_304403_mosangnvshi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
