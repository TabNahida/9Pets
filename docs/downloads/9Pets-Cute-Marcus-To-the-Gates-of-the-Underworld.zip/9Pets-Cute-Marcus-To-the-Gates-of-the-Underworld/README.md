# 9Pets-Cute-Marcus-To-the-Gates-of-the-Underworld

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306504.
Skin: To the Gates of the Underworld.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_306504_mks.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_306504_mks
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/s01_306504_makusi

Install by copying the package folder contents into your Codex pets directory.
