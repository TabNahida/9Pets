# 9Pets-Cute-APPLe-Echoing-to-Woodstock

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302803.
Skin: Echoing to Woodstock.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302803_apple.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302803_apple
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
