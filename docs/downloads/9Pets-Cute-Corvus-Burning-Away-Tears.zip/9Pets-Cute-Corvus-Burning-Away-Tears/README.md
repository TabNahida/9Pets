# 9Pets-Cute-Corvus-Burning-Away-Tears

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 313203.
Skin: Burning Away Tears.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a5_313203_gsn.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a5_313203_gsn
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a5_313203_gsn

Install by copying the package folder contents into your Codex pets directory.
