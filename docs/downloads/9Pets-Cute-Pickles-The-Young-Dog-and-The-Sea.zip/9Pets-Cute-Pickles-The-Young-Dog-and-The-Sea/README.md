# 9Pets-Cute-Pickles-The-Young-Dog-and-The-Sea

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306303.
Skin: The Young Dog and The Sea.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_306303_pikelesi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_306303_pikelesi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306303_pikelesi

Install by copying the package folder contents into your Codex pets directory.
