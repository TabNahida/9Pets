# 9Pets-Cute-Windsong-Records-from-the-Jade-Hunt

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307703.
Skin: Records from the Jade Hunt.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_307703_bfsg.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_307703_bfsg
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a5_307703_bfsg

Install by copying the package folder contents into your Codex pets directory.
