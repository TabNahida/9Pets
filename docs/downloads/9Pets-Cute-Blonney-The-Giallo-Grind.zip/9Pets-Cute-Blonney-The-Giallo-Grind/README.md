# 9Pets-Cute-Blonney-The-Giallo-Grind

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306003.
Skin: The Giallo Grind.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_306003_jinmier.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_306003_jinmier
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a1_306003_jinmier

Install by copying the package folder contents into your Codex pets directory.
