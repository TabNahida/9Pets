# 9Pets-Cute-Necrologist-Last-Words

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303702.
Skin: Last Words.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303702_fugaoren.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303702_fugaoren
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/303702_fugaoren

Install by copying the package folder contents into your Codex pets directory.
