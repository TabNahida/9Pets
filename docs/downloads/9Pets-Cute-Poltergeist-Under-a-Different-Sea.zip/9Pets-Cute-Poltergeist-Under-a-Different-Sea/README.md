# 9Pets-Cute-Poltergeist-Under-a-Different-Sea

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304603.
Skin: Under a Different Sea.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_304603_cng.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_304603_cng
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
