# 9Pets-Pickles-An-Indigo-Fluff

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 306302.
Skin: An Indigo Fluff.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/306302.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306302_pikelesi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306302_pikelesi

Install by copying the package folder contents into your Codex pets directory.
