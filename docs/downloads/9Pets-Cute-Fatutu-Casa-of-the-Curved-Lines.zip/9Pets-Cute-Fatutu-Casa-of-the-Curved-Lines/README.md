# 9Pets-Cute-Fatutu-Casa-of-the-Curved-Lines

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310903.
Skin: Casa of the Curved Lines.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_310903_ttsz.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_310903_ttsz
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a7_310903_ttsz

Install by copying the package folder contents into your Codex pets directory.
