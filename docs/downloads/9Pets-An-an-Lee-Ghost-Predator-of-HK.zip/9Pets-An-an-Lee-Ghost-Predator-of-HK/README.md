# 9Pets-An-an-Lee-Ghost-Predator-of-HK

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 303902.
Skin: Ghost Predator of HK.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/303902.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303902_nimengdishi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/303902_nimengdishi

Install by copying the package folder contents into your Codex pets directory.
