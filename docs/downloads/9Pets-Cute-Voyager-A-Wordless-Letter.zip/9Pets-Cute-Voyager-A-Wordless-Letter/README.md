# 9Pets-Cute-Voyager-A-Wordless-Letter

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304802.
Skin: A Wordless Letter.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304802_yuanlv.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304802_yuanlv
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/304802_yuanlv

Install by copying the package folder contents into your Codex pets directory.
