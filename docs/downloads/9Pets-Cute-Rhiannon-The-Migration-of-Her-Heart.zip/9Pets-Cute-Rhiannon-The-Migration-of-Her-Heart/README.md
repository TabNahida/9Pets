# 9Pets-Cute-Rhiannon-The-Migration-of-Her-Heart

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 314602.
Skin: The Migration of Her Heart.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_314602_xran.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_314602_xran
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_314602_xran

Install by copying the package folder contents into your Codex pets directory.
