# 9Pets-Cute-Regulus-The-Fierce-Fan

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302503.
Skin: The Fierce Fan.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/500503_xingti2hao.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/500503_xingti2hao
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
