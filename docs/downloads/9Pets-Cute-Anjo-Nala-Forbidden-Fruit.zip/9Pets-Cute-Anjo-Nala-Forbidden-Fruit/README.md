# 9Pets-Cute-Anjo-Nala-Forbidden-Fruit

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310003.
Skin: Forbidden Fruit.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_310003_tsnn.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_310003_tsnn
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a2_310003_tsnn

Install by copying the package folder contents into your Codex pets directory.
