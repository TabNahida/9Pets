# 9Pets-Sonetto-Parade-Anthem

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 302303.
Skin: Parade Anthem.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/302303.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302303_shisihangshi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/302303_shisihangshipifu

Install by copying the package folder contents into your Codex pets directory.
