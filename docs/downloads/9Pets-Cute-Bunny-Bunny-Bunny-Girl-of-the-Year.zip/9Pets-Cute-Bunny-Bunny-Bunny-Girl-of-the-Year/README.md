# 9Pets-Cute-Bunny-Bunny-Bunny-Girl-of-the-Year

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301402.
Skin: Bunny Girl of the Year.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301402_banibani.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301402_banibani
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
