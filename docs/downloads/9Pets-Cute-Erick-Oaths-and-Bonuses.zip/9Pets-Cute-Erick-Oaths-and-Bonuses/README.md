# 9Pets-Cute-Erick-Oaths-and-Bonuses

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305803.
Skin: Oaths and Bonuses.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_305803_alk.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_305803_alk
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
