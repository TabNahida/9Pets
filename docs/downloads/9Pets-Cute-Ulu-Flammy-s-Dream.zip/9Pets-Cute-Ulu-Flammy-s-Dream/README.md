# 9Pets-Cute-Ulu-Flammy-s-Dream

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307602.
Skin: Flammy's Dream.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_307602_hepingwulu.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_307602_hepingwulu
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
