# 9Pets-Cute-Melania-A-Peaceful-Night

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306203.
Skin: A Peaceful Night.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_306203_meilanni.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_306203_meilanni
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a7_306203_meilanni

Install by copying the package folder contents into your Codex pets directory.
