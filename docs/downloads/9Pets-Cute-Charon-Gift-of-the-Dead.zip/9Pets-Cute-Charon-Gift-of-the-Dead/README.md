# 9Pets-Cute-Charon-Gift-of-the-Dead

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312803.
Skin: Gift of the Dead.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_312803_kr.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_312803_kr
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_312803_kr

Install by copying the package folder contents into your Codex pets directory.
