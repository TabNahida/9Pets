# 9Pets-Cute-37-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306601.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_306601_37.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_306601_37
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a4_306601_37

Install by copying the package folder contents into your Codex pets directory.
