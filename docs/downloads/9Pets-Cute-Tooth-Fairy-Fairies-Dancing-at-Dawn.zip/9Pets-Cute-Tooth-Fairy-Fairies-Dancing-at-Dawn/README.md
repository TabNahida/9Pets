# 9Pets-Cute-Tooth-Fairy-Fairies-Dancing-at-Dawn

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305304.
Skin: Fairies Dancing at Dawn.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_305304_yx.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_305304_yx
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a3_305304_yaxian

Install by copying the package folder contents into your Codex pets directory.
