# 9Pets-Cute-Ezra-Theodore-Yee-Haw

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307403.
Skin: Yee-Haw!.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_307403_aizila.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_307403_aizila
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a1_307403_aizila

Install by copying the package folder contents into your Codex pets directory.
