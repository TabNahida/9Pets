# 9Pets-Cute-Name-Day-The-Deathless-Quiet

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311803.
Skin: The Deathless Quiet.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_311803_mmr.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_311803_mmr
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_311803_mmr

Install by copying the package folder contents into your Codex pets directory.
