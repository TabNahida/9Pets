# 9Pets-Cute-Dikke-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302201.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302201_pamiai.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302201_pamiai
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/302201_pamiai

Install by copying the package folder contents into your Codex pets directory.
