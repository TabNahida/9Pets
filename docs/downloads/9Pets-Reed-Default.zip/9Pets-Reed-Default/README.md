# 9Pets-Reed-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official art atlas; Live2D path mapped.
Official asset id: 313801.
Skin: Default.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/313801.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_313801_lcj
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
