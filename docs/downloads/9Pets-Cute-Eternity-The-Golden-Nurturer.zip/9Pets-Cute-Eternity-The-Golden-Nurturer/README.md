# 9Pets-Cute-Eternity-The-Golden-Nurturer

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305104.
Skin: The Golden Nurturer.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_305104_wnfld.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_305104_wnfld
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/s01_305104_wnfld

Install by copying the package folder contents into your Codex pets directory.
