# 9Pets-Cute-Rubuska-Song-of-the-Shadow-Dancer

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312503.
Skin: Song of the Shadow Dancer.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_312503_ysm.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_312503_ysm
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_312503_ysm

Install by copying the package folder contents into your Codex pets directory.
