# 9Pets-Cute-Kiperina-The-Universe-in-the-Rook-s-Shell

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311703.
Skin: The Universe in the Rook's Shell.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_311703_kphh.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_311703_kphh
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a8_311703_kphh

Install by copying the package folder contents into your Codex pets directory.
