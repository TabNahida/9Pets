# 9Pets-Noire-On-the-Red-Carpet

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 311102.
Skin: On the Red Carpet.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/311102.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_311102_flsd
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a5_311102_feilinshiduo

Install by copying the package folder contents into your Codex pets directory.
