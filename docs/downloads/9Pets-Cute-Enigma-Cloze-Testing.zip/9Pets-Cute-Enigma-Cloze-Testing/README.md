# 9Pets-Cute-Enigma-Cloze-Testing

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 314302.
Skin: Cloze Testing.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a6_314302_ym.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a6_314302_ym
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a6_314302_yami

Install by copying the package folder contents into your Codex pets directory.
