# 9Pets-Cute-Nautika-From-Darkness-Light

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312003.
Skin: From Darkness, Light.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_312003_ndk.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_312003_ndk
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_312003_ndk

Install by copying the package folder contents into your Codex pets directory.
