# 9Pets-Cute-Sonetto-Parade-Anthem

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302303.
Skin: Parade Anthem.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302303_shisihangshi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302303_shisihangshi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/302303_shisihangshipifu

Install by copying the package folder contents into your Codex pets directory.
