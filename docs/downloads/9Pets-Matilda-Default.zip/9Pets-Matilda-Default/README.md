# 9Pets-Matilda-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 304101.
Skin: Default.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/304101.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304101_madierda
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/304101_madierda

Install by copying the package folder contents into your Codex pets directory.
