# 9Pets-Cute-Jessica-Voyage-from-your-Bed

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305603.
Skin: Voyage from your Bed.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_305603_jiexika.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_305603_jiexika
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_305603_jiexika

Install by copying the package folder contents into your Codex pets directory.
