# 9Pets-Dikke-Sword-of-Hammurabi

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 302202.
Skin: Sword of Hammurabi.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/302202.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302202_pamiai
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/302202_pamiai

Install by copying the package folder contents into your Codex pets directory.
