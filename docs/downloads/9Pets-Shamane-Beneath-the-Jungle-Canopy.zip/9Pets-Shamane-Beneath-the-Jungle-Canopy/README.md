# 9Pets-Shamane-Beneath-the-Jungle-Canopy

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 307203.
Skin: Beneath the Jungle Canopy.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/307203.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_307203_zmsl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a2_307203_zmsl

Install by copying the package folder contents into your Codex pets directory.
