# 9Pets-Jiu-Niangzi

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official art atlas; Live2D path mapped.
Official asset id: 308301.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/store/skin/308301.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_308301_qn
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/308301_quniang

Install by copying the package folder contents into your Codex pets directory.
