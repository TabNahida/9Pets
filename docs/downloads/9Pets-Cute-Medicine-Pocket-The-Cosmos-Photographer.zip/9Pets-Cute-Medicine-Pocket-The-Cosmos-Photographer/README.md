# 9Pets-Cute-Medicine-Pocket-The-Cosmos-Photographer

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304703.
Skin: The Cosmos Photographer.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_304703_tumaoshoudai.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_304703_tumaoshoudai
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a8_304703_tumaoshoudai

Install by copying the package folder contents into your Codex pets directory.
