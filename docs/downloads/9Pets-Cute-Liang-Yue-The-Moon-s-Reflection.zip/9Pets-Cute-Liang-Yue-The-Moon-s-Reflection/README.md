# 9Pets-Cute-Liang-Yue-The-Moon-s-Reflection

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311003.
Skin: The Moon's Reflection.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_311003_ly.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_311003_ly
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_311003_ly

Install by copying the package folder contents into your Codex pets directory.
