# 9Pets-Cute-Balloon-Party-An-Uninvited-Guest

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302402.
Skin: An Uninvited Guest.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302402_qiqiupaidui.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302402_qiqiupaidui
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
