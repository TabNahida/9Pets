# 9Pets-Cute-37-A-Gift-of-Nourishment

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306605.
Skin: A Gift of Nourishment.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_306605_37.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_306605_37
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_306605_37

Install by copying the package folder contents into your Codex pets directory.
