# 9Pets-Cute-Mercuria-Midnight-Mistmancer

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309503.
Skin: Midnight Mistmancer.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_309503_hzsx.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_309503_hzsx
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a4_309503_hzsx

Install by copying the package folder contents into your Codex pets directory.
