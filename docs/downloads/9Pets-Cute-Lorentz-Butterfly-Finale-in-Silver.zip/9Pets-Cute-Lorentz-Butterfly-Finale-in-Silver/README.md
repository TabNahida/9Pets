# 9Pets-Cute-Lorentz-Butterfly-Finale-in-Silver

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 313903.
Skin: Finale in Silver.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_313903_llzhd.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_313903_llzhd
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a8_313903_llzhd

Install by copying the package folder contents into your Codex pets directory.
