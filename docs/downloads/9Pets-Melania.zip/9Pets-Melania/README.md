# 9Pets-Melania

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 306201.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/306201.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306201_meilanni
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306201_meilanni

Install by copying the package folder contents into your Codex pets directory.
