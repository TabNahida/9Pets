# 9Pets-Cute-Nautika

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312001.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_312001_ndk.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_312001_ndk
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a8_312001_ndk

Install by copying the package folder contents into your Codex pets directory.
