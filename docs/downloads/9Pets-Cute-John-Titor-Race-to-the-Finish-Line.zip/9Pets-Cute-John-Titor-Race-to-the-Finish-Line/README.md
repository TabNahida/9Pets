# 9Pets-Cute-John-Titor-Race-to-the-Finish-Line

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303602.
Skin: Race to the Finish Line.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_303602_yhtt.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_303602_yhtt
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
