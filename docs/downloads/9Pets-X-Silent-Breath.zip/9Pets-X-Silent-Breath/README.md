# 9Pets-X-Silent-Breath

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 301003.
Skin: Silent Breath.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/301003.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301003_x
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/301003_x

Install by copying the package folder contents into your Codex pets directory.
