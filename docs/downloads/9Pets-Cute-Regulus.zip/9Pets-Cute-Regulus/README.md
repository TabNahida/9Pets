# 9Pets-Cute-Regulus

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 500501.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/500501_xingti2hao.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/500501_xingti2hao
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_302504_xingti

Install by copying the package folder contents into your Codex pets directory.
