# 9Pets-Cute-Hissabeth-Digital-Jungle

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311602.
Skin: Digital Jungle.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_311602_lzl.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_311602_lzl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a7_311602_lzl

Install by copying the package folder contents into your Codex pets directory.
