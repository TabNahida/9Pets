# 9Pets-Medicine-Pocket-Beware-of-Dog

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 304702.
Skin: Beware of Dog.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/304702.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304702_tumaoshoudai
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/304702_tumaoshoudai

Install by copying the package folder contents into your Codex pets directory.
