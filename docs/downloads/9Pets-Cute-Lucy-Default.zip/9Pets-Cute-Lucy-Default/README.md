# 9Pets-Cute-Lucy-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308601.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_308601_luxi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_308601_luxi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_308601_luxi

Install by copying the package folder contents into your Codex pets directory.
