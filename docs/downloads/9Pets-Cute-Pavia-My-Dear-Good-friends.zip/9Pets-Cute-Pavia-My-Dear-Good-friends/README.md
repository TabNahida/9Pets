# 9Pets-Cute-Pavia-My-Dear-Good-friends

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301502.
Skin: My Dear Good friends.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301502_langqun.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301502_langqun
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
