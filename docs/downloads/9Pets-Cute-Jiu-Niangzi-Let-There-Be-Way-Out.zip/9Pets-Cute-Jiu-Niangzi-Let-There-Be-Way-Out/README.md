# 9Pets-Cute-Jiu-Niangzi-Let-There-Be-Way-Out

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308302.
Skin: Let There Be Way Out.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_308302_qn.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_308302_qn
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a6_308302_quniang

Install by copying the package folder contents into your Codex pets directory.
