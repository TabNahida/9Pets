# 9Pets-Melania-The-Ramirez-Style

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 306202.
Skin: The Ramirez Style.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/306202.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306202_meilanni
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306202_meilanni

Install by copying the package folder contents into your Codex pets directory.
