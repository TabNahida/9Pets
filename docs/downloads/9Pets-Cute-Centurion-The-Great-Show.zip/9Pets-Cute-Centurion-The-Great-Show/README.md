# 9Pets-Cute-Centurion-The-Great-Show

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303202.
Skin: The Great Show.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303202_baifuzhang.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303202_baifuzhang
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
