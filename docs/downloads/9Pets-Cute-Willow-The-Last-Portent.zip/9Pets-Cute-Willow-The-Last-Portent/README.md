# 9Pets-Cute-Willow-The-Last-Portent

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310403.
Skin: The Last Portent.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_310403_ddg.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_310403_ddg
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a6_310403_ddg

Install by copying the package folder contents into your Codex pets directory.
