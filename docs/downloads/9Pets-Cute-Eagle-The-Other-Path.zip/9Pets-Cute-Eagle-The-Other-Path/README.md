# 9Pets-Cute-Eagle-The-Other-Path

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300602.
Skin: The Other Path.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300602_xiaochunqueer.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300602_xiaochunqueer
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
