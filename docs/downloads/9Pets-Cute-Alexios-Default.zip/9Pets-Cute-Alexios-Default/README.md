# 9Pets-Cute-Alexios-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312201.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_312201_alkxos.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_312201_alkxos
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/s01_312201_alexios

Install by copying the package folder contents into your Codex pets directory.
