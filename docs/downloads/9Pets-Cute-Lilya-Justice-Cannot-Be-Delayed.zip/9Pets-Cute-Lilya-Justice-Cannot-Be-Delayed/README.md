# 9Pets-Cute-Lilya-Justice-Cannot-Be-Delayed

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300404.
Skin: Justice Cannot Be Delayed.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_300404_hnj.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_300404_hnj
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a3_300404_hongnujian

Install by copying the package folder contents into your Codex pets directory.
