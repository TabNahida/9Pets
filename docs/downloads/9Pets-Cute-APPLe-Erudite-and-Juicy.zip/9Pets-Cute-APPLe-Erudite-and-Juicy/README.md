# 9Pets-Cute-APPLe-Erudite-and-Juicy

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302802.
Skin: Erudite and Juicy.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302802_apple.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302802_apple
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
