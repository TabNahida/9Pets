# 9Pets-Cute-Medicine-Pocket-Forever-Is-Too-Short

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304704.
Skin: Forever Is Too Short.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_304704_tmsd.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_304704_tmsd
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a3_304704_tmsd

Install by copying the package folder contents into your Codex pets directory.
