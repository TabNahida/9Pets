# 9Pets-Cute-TTT-The-Girl-in-the-Frame

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303302.
Skin: The Girl in the Frame.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303302_ttt.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303302_ttt
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
