# 9Pets-Cute-Bunny-Bunny-Service-Fit-for-Royalty

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301403.
Skin: Service Fit for Royalty.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_301403_bnbn.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_301403_bnbn
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
