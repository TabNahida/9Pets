# 9Pets-Cute-Brimley-Sunset-Sartor

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310602.
Skin: Sunset Sartor.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_310602_kym.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_310602_kym
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a3_310602_kym

Install by copying the package folder contents into your Codex pets directory.
