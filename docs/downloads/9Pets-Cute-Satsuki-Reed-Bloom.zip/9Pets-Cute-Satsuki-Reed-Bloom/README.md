# 9Pets-Cute-Satsuki-Reed-Bloom

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303802.
Skin: Reed Bloom.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303802_wuseyue.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303802_wuseyue
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/303802_wuseyue

Install by copying the package folder contents into your Codex pets directory.
