# 9Pets-Cute-Diggers-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306401.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306401_wajueyishu.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306401_wajueyishu
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306401_wajueyishu

Install by copying the package folder contents into your Codex pets directory.
