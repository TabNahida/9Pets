# 9Pets-Cute-Rabies-Catcher-in-the-Rye

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304202.
Skin: Catcher in the Rye.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304202_aichong.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304202_aichong
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
