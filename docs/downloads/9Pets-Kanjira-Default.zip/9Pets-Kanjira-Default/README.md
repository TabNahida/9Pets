# 9Pets-Kanjira-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 307101.
Skin: Default.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/307101.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_307101_kanjila
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/307101_kanjila

Install by copying the package folder contents into your Codex pets directory.
