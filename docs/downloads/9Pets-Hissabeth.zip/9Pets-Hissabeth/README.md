# 9Pets-Hissabeth

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official art atlas; Live2D path mapped.
Official asset id: 311601.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/store/skin/311601.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_311601_lzl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/311601_lzl

Install by copying the package folder contents into your Codex pets directory.
