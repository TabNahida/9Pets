# 9Pets-Eagle

Fan-made Codex pet package for Reverse: 1999.
Source mode: prydwen-sourced.
Source URL: https://cdn.prydwen.gg/images/re1999/characters/eagle_full.webp

Install by copying the package folder contents into your Codex pets directory.
