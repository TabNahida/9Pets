# 9Pets-Cute-37-A-Prime-Number

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306602.
Skin: A Prime Number.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_306602_37.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_306602_37
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a4_306602_37

Install by copying the package folder contents into your Codex pets directory.
