# 9Pets-Cute-Diggers-Another-Assumption

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306403.
Skin: Another Assumption.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_306403_wajueyishu.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_306403_wajueyishu
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a4_306403_wajueyishu

Install by copying the package folder contents into your Codex pets directory.
