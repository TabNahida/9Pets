# 9Pets-Cute-Pickles-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306301.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306301_pikelesi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306301_pikelesi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306301_pikelesi

Install by copying the package folder contents into your Codex pets directory.
