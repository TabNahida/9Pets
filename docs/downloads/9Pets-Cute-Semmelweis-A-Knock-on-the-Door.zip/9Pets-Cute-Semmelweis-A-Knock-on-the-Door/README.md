# 9Pets-Cute-Semmelweis-A-Knock-on-the-Door

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308803.
Skin: A Knock on the Door.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_308803_smews.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_308803_smews
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a3_308803_smews

Install by copying the package folder contents into your Codex pets directory.
