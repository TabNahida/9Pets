# 9Pets-Tooth-Fairy-Fairies-Dancing-at-Dawn

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 305304.
Skin: Fairies Dancing at Dawn.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/305304.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_305304_yx
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a3_305304_yaxian

Install by copying the package folder contents into your Codex pets directory.
