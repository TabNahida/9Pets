# 9Pets-Cute-Cristallo-Bouquet-for-the-Bold

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303102.
Skin: Bouquet for the Bold.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303102_qianboli.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303102_qianboli
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
