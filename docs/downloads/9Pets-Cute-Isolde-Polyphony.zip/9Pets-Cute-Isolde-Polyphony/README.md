# 9Pets-Cute-Isolde-Polyphony

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308102.
Skin: Polyphony.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_308102_ysed.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_308102_ysed
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a7_308102_yisuoerde

Install by copying the package folder contents into your Codex pets directory.
