# 9Pets-Cute-Kanjira-The-Night-Visitor

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307103.
Skin: The Night Visitor.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_307103_kjl.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_307103_kjl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a0_307103_kjl

Install by copying the package folder contents into your Codex pets directory.
