# 9Pets-Cute-Marcus-A-Returning-Wind

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306502.
Skin: A Returning Wind.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_306502_makusi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_306502_makusi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a7_306502_makusi

Install by copying the package folder contents into your Codex pets directory.
