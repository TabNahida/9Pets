# 9Pets-Cute-Barcarola-Asteroid-Allegro

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310803.
Skin: Asteroid Allegro.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_310803_bkle.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_310803_bkle
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a7_310803_bkle

Install by copying the package folder contents into your Codex pets directory.
