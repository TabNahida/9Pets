# 9Pets-Cute-Tuesday-Miss-Horror

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309802.
Skin: Miss Horror.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_309802_lsp.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_309802_lsp
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a1_309802_lsp

Install by copying the package folder contents into your Codex pets directory.
