# 9Pets-Cute-Tooth-Fairy-The-Woven-Legend

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305305.
Skin: The Woven Legend.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_305305_yx.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_305305_yx
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_305305_yx

Install by copying the package folder contents into your Codex pets directory.
