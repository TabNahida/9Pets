# 9Pets-Cute-Baby-Blue-The-New-Red-Queen

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301602.
Skin: The New "Red Queen".
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301602_yingerlan.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301602_yingerlan
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
