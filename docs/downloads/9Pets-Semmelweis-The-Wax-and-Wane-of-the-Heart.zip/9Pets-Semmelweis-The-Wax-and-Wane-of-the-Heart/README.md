# 9Pets-Semmelweis-The-Wax-and-Wane-of-the-Heart

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 308804.
Skin: The Wax and Wane of the Heart.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/308804.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_308804_smews
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a0_308804_smews

Install by copying the package folder contents into your Codex pets directory.
