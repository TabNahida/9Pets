# 9Pets-Cute-Alexios-Second-Conquest

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312202.
Skin: Second Conquest.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_312202_alkxos.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_312202_alkxos
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/s01_312202_alexios

Install by copying the package folder contents into your Codex pets directory.
