# 9Pets-Cute-Name-Day-Before-the-Light-Fades

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311802.
Skin: Before the Light Fades.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_311802_mmr.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_311802_mmr
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a7_311802_mmr

Install by copying the package folder contents into your Codex pets directory.
