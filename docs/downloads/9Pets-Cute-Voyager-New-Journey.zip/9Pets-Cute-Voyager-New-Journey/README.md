# 9Pets-Cute-Voyager-New-Journey

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304803.
Skin: New Journey.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_304803_yuanlv.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_304803_yuanlv
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_304803_yuanlv

Install by copying the package folder contents into your Codex pets directory.
