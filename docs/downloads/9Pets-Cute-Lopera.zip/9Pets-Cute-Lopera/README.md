# 9Pets-Cute-Lopera

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310201.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_310201_lopera.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_310201_lopera
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a2_310201_luopeila

Install by copying the package folder contents into your Codex pets directory.
