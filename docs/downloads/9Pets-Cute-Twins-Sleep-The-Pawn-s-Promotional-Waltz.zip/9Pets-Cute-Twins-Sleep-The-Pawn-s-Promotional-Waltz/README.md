# 9Pets-Cute-Twins-Sleep-The-Pawn-s-Promotional-Waltz

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304002.
Skin: The Pawn's Promotional Waltz.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_304002_lisha&luyisi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_304002_lisha&luyisi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
