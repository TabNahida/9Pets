# 9Pets-Cute-Druvis-III-Shrouded-in-Thorns

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300306.
Skin: Shrouded in Thorns.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_300306_hjs.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_300306_hjs
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a5_300306_hjs

Install by copying the package folder contents into your Codex pets directory.
