# 9Pets-Cute-Semmelweis-The-Mirror

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308802.
Skin: The Mirror.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_308802_smews.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_308802_smews
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_308802_smews

Install by copying the package folder contents into your Codex pets directory.
