# 9Pets-Cute-Melania-Red-and-White

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306204.
Skin: Red and White.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_306204_mln.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_306204_mln
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a6_306204_meilanni

Install by copying the package folder contents into your Codex pets directory.
