# 9Pets-Cute-Kaalaa-Baunaa-Swing-Rise-Suspend

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307003.
Skin: Swing, Rise, Suspend.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_307003_jialabona.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_307003_jialabona
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a0_307003_jialabona

Install by copying the package folder contents into your Codex pets directory.
