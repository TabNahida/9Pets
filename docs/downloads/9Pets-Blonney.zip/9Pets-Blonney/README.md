# 9Pets-Blonney

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 306001.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/store/skin/306001.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306001_jinmier
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306001_jinmier

Install by copying the package folder contents into your Codex pets directory.
