# 9Pets-Cute-Silverwing-Eagle

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 315401.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_315401_yzxcqe.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_315401_yzxcqe
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_315401_spxcqe

Install by copying the package folder contents into your Codex pets directory.
