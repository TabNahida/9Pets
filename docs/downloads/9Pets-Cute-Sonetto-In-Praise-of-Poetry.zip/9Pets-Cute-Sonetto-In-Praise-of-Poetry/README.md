# 9Pets-Cute-Sonetto-In-Praise-of-Poetry

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302306.
Skin: In Praise of Poetry.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_302306_sshs.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_302306_sshs
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a8_302306_sshs

Install by copying the package folder contents into your Codex pets directory.
