# 9Pets-Cute-The-Fool-The-Shadow-Play-Master

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301202.
Skin: The Shadow Play Master.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_301202_nc.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_301202_nc
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
