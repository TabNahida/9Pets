# 9Pets-Semmelweis

Fan-made Codex pet package for Reverse: 1999.
Source mode: generated-card.
Source URL: Generated from character catalog metadata.

Install by copying the package folder contents into your Codex pets directory.
