# 9Pets-Cute-Enigma

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 314301.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a6_314301_ym.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a6_314301_ym
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a6_314301_yami

Install by copying the package folder contents into your Codex pets directory.
