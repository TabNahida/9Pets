# 9Pets-Cute-Eternity-A-Visit-to-the-Arctic

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305103.
Skin: A Visit to the Arctic.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_305103_wnfld.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_305103_wnfld
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a8_305103_wnfld

Install by copying the package folder contents into your Codex pets directory.
