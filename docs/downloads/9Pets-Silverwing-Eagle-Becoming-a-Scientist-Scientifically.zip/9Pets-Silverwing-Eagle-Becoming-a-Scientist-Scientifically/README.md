# 9Pets-Silverwing-Eagle-Becoming-a-Scientist-Scientifically

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 315402.
Skin: Becoming a Scientist, Scientifically.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/315402.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_315402_yzxcqe
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_315402_spxcqe

Install by copying the package folder contents into your Codex pets directory.
