# 9Pets-Cute-J

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309401.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_309401_j.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_309401_j
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a0_309401_j

Install by copying the package folder contents into your Codex pets directory.
