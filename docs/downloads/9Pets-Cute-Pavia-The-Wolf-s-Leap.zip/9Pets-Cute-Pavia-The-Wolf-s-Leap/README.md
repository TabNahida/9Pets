# 9Pets-Cute-Pavia-The-Wolf-s-Leap

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301503.
Skin: The Wolf's Leap.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_301503_langqun.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_301503_langqun
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
