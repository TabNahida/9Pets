# 9Pets-Cute-Tuesday-Story-of-the-Jade-Vase

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309803.
Skin: Story of the Jade Vase.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_309803_lsp.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_309803_lsp
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a5_309803_lsp

Install by copying the package folder contents into your Codex pets directory.
