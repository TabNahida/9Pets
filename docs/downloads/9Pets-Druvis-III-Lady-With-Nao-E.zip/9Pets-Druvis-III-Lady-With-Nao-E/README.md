# 9Pets-Druvis-III-Lady-With-Nao-E

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 300305.
Skin: Lady With Nao'E.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/300305.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_300305_hjs
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a6_300305_hujisheng

Install by copying the package folder contents into your Codex pets directory.
