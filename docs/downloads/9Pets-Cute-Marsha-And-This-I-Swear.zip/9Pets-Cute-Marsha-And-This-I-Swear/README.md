# 9Pets-Cute-Marsha-And-This-I-Swear

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312702.
Skin: And This I Swear.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_312702_mes.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_312702_mes
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a3_312702_mes

Install by copying the package folder contents into your Codex pets directory.
