# 9Pets-Cute-Desert-Flannel-Call-of-the-Wild

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307503.
Skin: Call of the Wild.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_307503_shasirong.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_307503_shasirong
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_307503_shasirong

Install by copying the package folder contents into your Codex pets directory.
