# 9Pets-Cute-Reed-The-Everlasting-Scribbler

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 313802.
Skin: The Everlasting Scribbler.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_313802_lcj.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_313802_lcj
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
