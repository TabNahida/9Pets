# 9Pets-Cute-Hissabeth-Verses-to-Heaven

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311604.
Skin: Verses to Heaven.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_311604_lzl.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_311604_lzl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a8_311604_lzl

Install by copying the package folder contents into your Codex pets directory.
