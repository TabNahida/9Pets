# 9Pets-Cute-Isolde-And-All-That-Jazz

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308103.
Skin: And All That Jazz.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_308103_ysed.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a1_308103_ysed
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a1_308103_yisuoerde

Install by copying the package folder contents into your Codex pets directory.
