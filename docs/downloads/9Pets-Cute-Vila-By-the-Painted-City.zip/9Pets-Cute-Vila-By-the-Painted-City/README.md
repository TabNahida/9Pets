# 9Pets-Cute-Vila-By-the-Painted-City

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308703.
Skin: By the Painted City.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_308703_wl.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_308703_wl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a2_308703_wl

Install by copying the package folder contents into your Codex pets directory.
