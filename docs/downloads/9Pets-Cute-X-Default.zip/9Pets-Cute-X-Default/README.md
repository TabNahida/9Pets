# 9Pets-Cute-X-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301001.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301001_x.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301001_x
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/301001_x

Install by copying the package folder contents into your Codex pets directory.
