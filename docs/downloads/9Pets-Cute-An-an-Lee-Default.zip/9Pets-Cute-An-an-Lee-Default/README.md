# 9Pets-Cute-An-an-Lee-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303901.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303901_nimengdishi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303901_nimengdishi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/303901_nimengdishi

Install by copying the package folder contents into your Codex pets directory.
