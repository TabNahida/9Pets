# 9Pets-Cute-Sentinel-The-Shackles-of-Sin

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312602.
Skin: The Shackles of Sin.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_312602_mlan.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_312602_mlan
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a0_312602_mlan

Install by copying the package folder contents into your Codex pets directory.
