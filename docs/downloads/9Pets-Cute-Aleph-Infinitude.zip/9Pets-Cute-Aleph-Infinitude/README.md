# 9Pets-Cute-Aleph-Infinitude

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311302.
Skin: Infinitude.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_311302_alf.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_311302_alf
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a6_311302_alf

Install by copying the package folder contents into your Codex pets directory.
