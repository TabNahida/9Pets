# 9Pets-Cute-Lucy-A-Robot-Is-Born

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308602.
Skin: A Robot Is Born.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_308602_luxi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_308602_luxi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_308602_luxi

Install by copying the package folder contents into your Codex pets directory.
