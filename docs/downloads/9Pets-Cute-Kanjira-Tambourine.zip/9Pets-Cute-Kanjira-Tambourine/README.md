# 9Pets-Cute-Kanjira-Tambourine

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307102.
Skin: Tambourine.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_307102_kanjila.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_307102_kanjila
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/307102_kanjila

Install by copying the package folder contents into your Codex pets directory.
