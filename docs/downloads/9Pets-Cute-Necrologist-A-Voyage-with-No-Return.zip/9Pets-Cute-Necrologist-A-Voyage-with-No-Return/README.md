# 9Pets-Cute-Necrologist-A-Voyage-with-No-Return

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303703.
Skin: A Voyage with No Return.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_303703_fgr.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a4_303703_fgr
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a4_303703_fgr

Install by copying the package folder contents into your Codex pets directory.
