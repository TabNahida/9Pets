# 9Pets-Cute-Lucy-The-Queen-s-Game

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308603.
Skin: The Queen's Game.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_308603_lx.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_308603_lx
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a8_308603_lx

Install by copying the package folder contents into your Codex pets directory.
