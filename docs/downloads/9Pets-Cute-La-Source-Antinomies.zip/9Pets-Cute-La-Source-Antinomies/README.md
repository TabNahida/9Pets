# 9Pets-Cute-La-Source-Antinomies

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303002.
Skin: Antinomies.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_303003_lalaquan.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_303003_lalaquan
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
