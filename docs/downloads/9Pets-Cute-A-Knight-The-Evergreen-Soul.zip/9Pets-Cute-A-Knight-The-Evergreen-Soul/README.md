# 9Pets-Cute-A-Knight-The-Evergreen-Soul

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300731.
Skin: The Evergreen Soul.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a1_300731_wxk.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a1_300731_wxk
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a1_300731_wxk

Install by copying the package folder contents into your Codex pets directory.
