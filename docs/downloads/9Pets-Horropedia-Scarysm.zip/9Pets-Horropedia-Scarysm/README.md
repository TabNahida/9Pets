# 9Pets-Horropedia-Scarysm

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 306102.
Skin: Scarysm.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/306102.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306102_kongbutong
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306102_kongbutong

Install by copying the package folder contents into your Codex pets directory.
