# 9Pets-Cute-Vila-Towards-the-Ideal-Life

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308702.
Skin: Towards the Ideal Life.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_308702_weila.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_308702_weila
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a8_308702_weila

Install by copying the package folder contents into your Codex pets directory.
