# 9Pets-Cheng-Heguang

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 313701.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/313701.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_313701_chg
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_313701_chg

Install by copying the package folder contents into your Codex pets directory.
