# 9Pets-Cute-Aleph-A-Feast-of-Imagery

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311303.
Skin: A Feast of Imagery.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a1_311303_alf.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a1_311303_alf
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a1_311303_alf

Install by copying the package folder contents into your Codex pets directory.
