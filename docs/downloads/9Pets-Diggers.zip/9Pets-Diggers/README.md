# 9Pets-Diggers

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 306401.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/306401.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/306401_wajueyishu
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/306401_wajueyishu

Install by copying the package folder contents into your Codex pets directory.
