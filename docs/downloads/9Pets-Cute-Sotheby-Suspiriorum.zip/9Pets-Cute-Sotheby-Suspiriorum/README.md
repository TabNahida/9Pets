# 9Pets-Cute-Sotheby-Suspiriorum

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300903.
Skin: Suspiriorum.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300903_sfb.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300903_sfb
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/300903_sufubi

Install by copying the package folder contents into your Codex pets directory.
