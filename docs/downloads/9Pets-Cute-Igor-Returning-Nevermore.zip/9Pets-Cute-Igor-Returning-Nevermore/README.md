# 9Pets-Cute-Igor-Returning-Nevermore

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309203.
Skin: Returning Nevermore.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_309203_yge.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_309203_yge
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a8_309203_yge

Install by copying the package folder contents into your Codex pets directory.
