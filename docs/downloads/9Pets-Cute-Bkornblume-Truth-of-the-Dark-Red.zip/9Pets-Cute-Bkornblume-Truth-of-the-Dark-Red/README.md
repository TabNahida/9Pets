# 9Pets-Cute-Bkornblume-Truth-of-the-Dark-Red

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302003.
Skin: Truth of the Dark Red.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302003_bolinyidong.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302003_bolinyidong
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
