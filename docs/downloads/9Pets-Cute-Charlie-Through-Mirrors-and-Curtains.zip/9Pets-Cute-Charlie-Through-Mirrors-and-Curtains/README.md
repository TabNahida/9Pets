# 9Pets-Cute-Charlie-Through-Mirrors-and-Curtains

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301703.
Skin: Through Mirrors and Curtains.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301703_xiali.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301703_xiali
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
