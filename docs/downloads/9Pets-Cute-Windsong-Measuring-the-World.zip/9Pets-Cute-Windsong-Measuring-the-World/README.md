# 9Pets-Cute-Windsong-Measuring-the-World

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307702.
Skin: Measuring the World.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_307702_beifangshaoge.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_307702_beifangshaoge
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a8_307702_beifangshaoge

Install by copying the package folder contents into your Codex pets directory.
