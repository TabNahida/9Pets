# 9Pets-Cute-Sentinel

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312601.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_312601_mlan.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_312601_mlan
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a0_312601_mlan

Install by copying the package folder contents into your Codex pets directory.
