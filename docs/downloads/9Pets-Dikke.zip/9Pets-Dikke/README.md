# 9Pets-Dikke

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official art atlas; Live2D path mapped.
Official asset id: 302201.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/store/skin/302201.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302201_pamiai
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/302201_pamiai

Install by copying the package folder contents into your Codex pets directory.
