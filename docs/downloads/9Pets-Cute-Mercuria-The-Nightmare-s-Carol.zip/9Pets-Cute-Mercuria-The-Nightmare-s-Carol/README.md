# 9Pets-Cute-Mercuria-The-Nightmare-s-Carol

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309504.
Skin: The Nightmare's Carol.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_309504_hzsx.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_309504_hzsx
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a3_309504_hzsx

Install by copying the package folder contents into your Codex pets directory.
