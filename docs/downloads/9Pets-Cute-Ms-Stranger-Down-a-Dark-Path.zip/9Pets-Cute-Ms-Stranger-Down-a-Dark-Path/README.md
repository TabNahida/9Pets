# 9Pets-Cute-Ms-Stranger-Down-a-Dark-Path

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 314702.
Skin: Down a Dark Path.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_314702_wmz.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_314702_wmz
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_314702_wmz

Install by copying the package folder contents into your Codex pets directory.
