# 9Pets-Cute-Cheng-Heguang-Breaking-Free-from-a-Burning-Cage

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 313702.
Skin: Breaking Free from a Burning Cage.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_313702_chg.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_313702_chg
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_313702_chg

Install by copying the package folder contents into your Codex pets directory.
