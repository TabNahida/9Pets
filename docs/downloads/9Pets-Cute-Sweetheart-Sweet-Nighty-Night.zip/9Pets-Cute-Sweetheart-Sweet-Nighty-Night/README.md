# 9Pets-Cute-Sweetheart-Sweet-Nighty-Night

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301102.
Skin: Sweet Nighty Night.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301102_malilian.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301102_malilian
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
