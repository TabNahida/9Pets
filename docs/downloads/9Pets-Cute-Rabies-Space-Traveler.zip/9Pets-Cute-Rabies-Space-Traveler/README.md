# 9Pets-Cute-Rabies-Space-Traveler

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304203.
Skin: Space Traveler.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_304203_ac.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_304203_ac
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
