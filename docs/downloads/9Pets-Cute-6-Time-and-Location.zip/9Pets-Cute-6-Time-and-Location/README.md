# 9Pets-Cute-6-Time-and-Location

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307903.
Skin: Time and Location.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_307903_6.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_307903_6
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a0_307903_6

Install by copying the package folder contents into your Codex pets directory.
