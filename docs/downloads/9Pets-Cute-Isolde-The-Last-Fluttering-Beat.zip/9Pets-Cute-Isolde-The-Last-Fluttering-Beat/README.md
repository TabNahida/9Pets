# 9Pets-Cute-Isolde-The-Last-Fluttering-Beat

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308104.
Skin: The Last Fluttering Beat.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_308104_ysed.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_308104_ysed
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a2_308104_ysed

Install by copying the package folder contents into your Codex pets directory.
