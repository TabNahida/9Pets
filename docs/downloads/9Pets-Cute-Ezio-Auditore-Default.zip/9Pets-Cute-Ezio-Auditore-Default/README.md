# 9Pets-Cute-Ezio-Auditore-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312301.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_312301_ajaadtl.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_312301_ajaadtl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/s01_312301_aja

Install by copying the package folder contents into your Codex pets directory.
