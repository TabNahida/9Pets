# 9Pets-Cute-APPLe-The-Fruit-of-Wisdom

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302804.
Skin: The Fruit of Wisdom.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_302804_apple.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_302804_apple
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
