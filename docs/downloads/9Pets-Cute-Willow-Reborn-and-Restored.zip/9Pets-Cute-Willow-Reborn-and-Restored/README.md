# 9Pets-Cute-Willow-Reborn-and-Restored

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310404.
Skin: Reborn and Restored.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_310404_ddg.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_310404_ddg
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_310404_ddg

Install by copying the package folder contents into your Codex pets directory.
