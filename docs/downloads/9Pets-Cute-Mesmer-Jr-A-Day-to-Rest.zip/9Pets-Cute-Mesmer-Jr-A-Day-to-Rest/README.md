# 9Pets-Cute-Mesmer-Jr-A-Day-to-Rest

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305703.
Skin: A Day to Rest.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_305703_xmsmr.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_305703_xmsmr
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
