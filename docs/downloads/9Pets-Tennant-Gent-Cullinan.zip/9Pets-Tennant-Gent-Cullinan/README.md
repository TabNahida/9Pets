# 9Pets-Tennant-Gent-Cullinan

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 304302.
Skin: Gent Cullinan.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/304302.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304302_tannante
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/304302_tannante

Install by copying the package folder contents into your Codex pets directory.
