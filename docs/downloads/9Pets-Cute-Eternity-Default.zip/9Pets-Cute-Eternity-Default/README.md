# 9Pets-Cute-Eternity-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305101.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305101_wennifuleide.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305101_wennifuleide
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/305101_wennifuleide

Install by copying the package folder contents into your Codex pets directory.
