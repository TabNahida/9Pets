# 9Pets-Cute-Shamane-South-of-the-Mountain

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307202.
Skin: South of the Mountain.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_307202_zongmaoshali.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_307202_zongmaoshali
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/307202_zongmaoshali

Install by copying the package folder contents into your Codex pets directory.
