# 9Pets-Cute-Ms-Radio-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302701.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302701_wuxiandianxiaojie.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/302701_wuxiandianxiaojie
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
