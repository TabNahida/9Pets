# 9Pets-Cute-Mercuria-The-Universe-Holds-Its-Breath

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309502.
Skin: The Universe Holds Its Breath.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_309502_hzsx.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_309502_hzsx
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a0_309502_huanzhuangshuixing

Install by copying the package folder contents into your Codex pets directory.
