# 9Pets-Cute-Pioneer-Idol-Fascinations

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309602.
Skin: Idol Fascinations.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_309602_xqz.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_309602_xqz
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
