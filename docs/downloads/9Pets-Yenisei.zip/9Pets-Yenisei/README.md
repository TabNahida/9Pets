# 9Pets-Yenisei

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 308201.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/308201.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_308201_xyns
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a6_308201_xiaoyenisai

Install by copying the package folder contents into your Codex pets directory.
