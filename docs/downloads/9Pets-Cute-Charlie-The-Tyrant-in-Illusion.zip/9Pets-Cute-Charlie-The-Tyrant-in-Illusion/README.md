# 9Pets-Cute-Charlie-The-Tyrant-in-Illusion

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301702.
Skin: The Tyrant in Illusion.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301702_xiali.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301702_xiali
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
