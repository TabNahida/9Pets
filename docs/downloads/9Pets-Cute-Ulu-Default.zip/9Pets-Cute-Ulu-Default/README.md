# 9Pets-Cute-Ulu-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307601.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_307601_hepingwulu.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_307601_hepingwulu
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
