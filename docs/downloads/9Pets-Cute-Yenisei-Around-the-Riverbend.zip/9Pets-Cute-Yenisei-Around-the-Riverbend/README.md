# 9Pets-Cute-Yenisei-Around-the-Riverbend

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308203.
Skin: Around the Riverbend.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_308203_xyns.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_308203_xyns
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a2_308203_xyns

Install by copying the package folder contents into your Codex pets directory.
