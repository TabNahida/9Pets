# 9Pets-Cute-Mr-Duncan-The-Favela-Inventor

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310302.
Skin: The Favela Inventor.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_310302_dkxs.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_310302_dkxs
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a2_310302_dengken

Install by copying the package folder contents into your Codex pets directory.
