# 9Pets-Cute-Lorelei-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309101.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_309101_lorelei.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_309101_lorelei
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_309101_luoleilai

Install by copying the package folder contents into your Codex pets directory.
