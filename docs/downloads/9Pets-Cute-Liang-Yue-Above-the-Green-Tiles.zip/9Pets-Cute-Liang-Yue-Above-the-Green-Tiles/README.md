# 9Pets-Cute-Liang-Yue-Above-the-Green-Tiles

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311002.
Skin: Above the Green Tiles.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_311002_ly.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_311002_ly
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a5_311002_liangyue

Install by copying the package folder contents into your Codex pets directory.
