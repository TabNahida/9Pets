# 9Pets-Jessica-Hide-and-Seek

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 305602.
Skin: Hide and Seek.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/305602.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305602_jiexika
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/305602_jiexika

Install by copying the package folder contents into your Codex pets directory.
