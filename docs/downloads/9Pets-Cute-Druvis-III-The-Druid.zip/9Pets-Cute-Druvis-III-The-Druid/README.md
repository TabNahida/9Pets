# 9Pets-Cute-Druvis-III-The-Druid

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300302.
Skin: The Druid.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300303_hujisheng.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300303_hujisheng
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/300303_hujisheng

Install by copying the package folder contents into your Codex pets directory.
