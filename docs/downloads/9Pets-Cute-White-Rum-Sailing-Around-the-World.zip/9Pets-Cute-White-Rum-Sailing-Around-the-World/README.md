# 9Pets-Cute-White-Rum-Sailing-Around-the-World

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310103.
Skin: Sailing Around the World.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a6_310103_blm.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a6_310103_blm
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
