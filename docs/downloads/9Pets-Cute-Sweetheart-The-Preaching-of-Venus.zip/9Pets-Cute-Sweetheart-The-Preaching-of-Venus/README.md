# 9Pets-Cute-Sweetheart-The-Preaching-of-Venus

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301103.
Skin: The Preaching of Venus.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_301103_malilian.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a4_301103_malilian
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
