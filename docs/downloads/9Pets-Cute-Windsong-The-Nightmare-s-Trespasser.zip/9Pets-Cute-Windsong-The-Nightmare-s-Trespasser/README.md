# 9Pets-Cute-Windsong-The-Nightmare-s-Trespasser

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307704.
Skin: The Nightmare's Trespasser.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a1_307704_bfsg.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a1_307704_bfsg
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a1_307704_bfsg

Install by copying the package folder contents into your Codex pets directory.
