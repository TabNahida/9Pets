# 9Pets-Cute-Jiu-Niangzi-Blossom-Spring-Fairy

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308303.
Skin: Blossom Spring Fairy.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_308303_qn.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a5_308303_qn
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a5_308303_quniang

Install by copying the package folder contents into your Codex pets directory.
