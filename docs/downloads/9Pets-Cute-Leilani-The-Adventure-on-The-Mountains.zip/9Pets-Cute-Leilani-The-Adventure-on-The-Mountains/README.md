# 9Pets-Cute-Leilani-The-Adventure-on-The-Mountains

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303502.
Skin: The Adventure on The Mountains.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_303503_lilani.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_303503_lilani
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
