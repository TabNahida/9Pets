# 9Pets-Cute-Lopera-Friend-of-the-Splintercat

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310203.
Skin: Friend of the Splintercat.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_310203_lopera.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a6_310203_lopera
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a6_310203_luopeila

Install by copying the package folder contents into your Codex pets directory.
