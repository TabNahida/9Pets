# 9Pets-Marcus-To-the-Gates-of-the-Underworld

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 306504.
Skin: To the Gates of the Underworld.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/306504.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_306504_mks
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/s01_306504_makusi

Install by copying the package folder contents into your Codex pets directory.
