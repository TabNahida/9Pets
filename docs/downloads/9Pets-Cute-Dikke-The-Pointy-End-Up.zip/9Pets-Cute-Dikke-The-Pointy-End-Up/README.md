# 9Pets-Cute-Dikke-The-Pointy-End-Up

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302203.
Skin: The Pointy End Up.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_302203_pamiai.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_302203_pamiai
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a5_302203_pamiai

Install by copying the package folder contents into your Codex pets directory.
