# 9Pets-Cute-Flutterpage-Chirpy-Morning-Ringer

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310502.
Skin: Chirpy Morning Ringer.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_310502_zxqe.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_310502_zxqe
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a3_310502_zxqe

Install by copying the package folder contents into your Codex pets directory.
