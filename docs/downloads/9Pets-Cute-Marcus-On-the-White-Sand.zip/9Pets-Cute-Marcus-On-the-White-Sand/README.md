# 9Pets-Cute-Marcus-On-the-White-Sand

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306503.
Skin: On the White Sand.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_306503_mks.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a2_306503_mks
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a2_306503_mks

Install by copying the package folder contents into your Codex pets directory.
