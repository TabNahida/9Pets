# 9Pets-Cute-Paper-Heron-Downstream-of-Letting-Go

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 314102.
Skin: Downstream of Letting Go.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_314102_lsj.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a4_314102_lsj
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a4_314102_lsj

Install by copying the package folder contents into your Codex pets directory.
