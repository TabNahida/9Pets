# 9Pets-Cute-Baby-Blue-On-the-Sparrow-Hills

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301603.
Skin: On the Sparrow Hills.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_301603_yingerlan.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a8_301603_yingerlan
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
