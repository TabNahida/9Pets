# 9Pets-Cute-Ms-NewBabel-Creator-of-the-New-Era

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305202.
Skin: Creator of the New Era.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305202_xinbabieta.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305202_xinbabieta
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/305202_xinbabieta

Install by copying the package folder contents into your Codex pets directory.
