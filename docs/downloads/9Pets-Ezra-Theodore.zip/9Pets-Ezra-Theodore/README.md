# 9Pets-Ezra-Theodore

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 307401.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/307401.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_307401_aizila
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a5_307401_aizila

Install by copying the package folder contents into your Codex pets directory.
