# 9Pets-Cute-Coppelia-Song-of-the-Self-Playing-Instrument

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 314402.
Skin: Song of the Self-Playing Instrument.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_314402_fly.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_314402_fly
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_314402_fly

Install by copying the package folder contents into your Codex pets directory.
