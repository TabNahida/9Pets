# 9Pets-Lilya-Justice-Cannot-Be-Delayed

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 300404.
Skin: Justice Cannot Be Delayed.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/300404.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a3_300404_hnj
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a3_300404_hongnujian

Install by copying the package folder contents into your Codex pets directory.
