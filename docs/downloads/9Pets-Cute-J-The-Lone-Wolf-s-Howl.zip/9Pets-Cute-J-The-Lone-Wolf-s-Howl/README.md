# 9Pets-Cute-J-The-Lone-Wolf-s-Howl

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309403.
Skin: The Lone Wolf's Howl.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_309403_j.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_309403_j
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a0_309403_j

Install by copying the package folder contents into your Codex pets directory.
