# 9Pets-Cute-Zima-A-Day-in-the-Mountain

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 301303.
Skin: A Day in the Mountain.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_301303_dong.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_301303_dong
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
