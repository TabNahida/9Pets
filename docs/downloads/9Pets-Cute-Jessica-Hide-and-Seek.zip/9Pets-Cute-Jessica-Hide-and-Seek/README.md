# 9Pets-Cute-Jessica-Hide-and-Seek

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305602.
Skin: Hide and Seek.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305602_jiexika.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305602_jiexika
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/305602_jiexika

Install by copying the package folder contents into your Codex pets directory.
