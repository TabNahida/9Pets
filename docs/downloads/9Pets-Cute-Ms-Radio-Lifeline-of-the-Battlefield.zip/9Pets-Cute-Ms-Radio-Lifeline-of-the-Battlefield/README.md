# 9Pets-Cute-Ms-Radio-Lifeline-of-the-Battlefield

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 302702.
Skin: Lifeline of the Battlefield.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_302702_wxdxj.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_302702_wxdxj
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
