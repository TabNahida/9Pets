# 9Pets-Cute-Kiperina-A-Utopia-in-Painted-Glass

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311704.
Skin: A Utopia in Painted Glass.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a5_311704_kphh.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a5_311704_kphh
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a5_311704_kphh

Install by copying the package folder contents into your Codex pets directory.
