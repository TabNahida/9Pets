# 9Pets-Cute-Jessica-The-Sound-of-Paradise

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305604.
Skin: The Sound of Paradise.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_305604_jxk.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a8_305604_jxk
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a8_305604_jxk

Install by copying the package folder contents into your Codex pets directory.
