# 9Pets-Cute-Marsha-The-Ever-Burning-Embrace

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312703.
Skin: The Ever-Burning Embrace.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a6_312703_mes.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a6_312703_mes
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a6_312703_mes

Install by copying the package folder contents into your Codex pets directory.
