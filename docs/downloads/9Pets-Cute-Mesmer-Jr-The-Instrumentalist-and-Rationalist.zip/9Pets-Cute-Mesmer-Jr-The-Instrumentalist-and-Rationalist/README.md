# 9Pets-Cute-Mesmer-Jr-The-Instrumentalist-and-Rationalist

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305702.
Skin: The Instrumentalist & Rationalist.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305702_xiaomeisimeier.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305702_xiaomeisimeier
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
