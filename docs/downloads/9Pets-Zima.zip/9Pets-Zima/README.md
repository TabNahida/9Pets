# 9Pets-Zima

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Spine motion capture.
Official asset id: 301301.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/301301.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301301_dong
Live2D assets: No mapped Live2D path.

Install by copying the package folder contents into your Codex pets directory.
