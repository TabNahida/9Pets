# 9Pets-Zima

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official art atlas; Live2D path mapped.
Official asset id: 301301.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/store/skin/301301.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/301301_dong
Live2D assets: No mapped Live2D path.

Install by copying the package folder contents into your Codex pets directory.
