# 9Pets-Cute-Kaalaa-Baunaa-The-Star-Reader

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307002.
Skin: The Star Reader.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_307002_jialabona.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a3_307002_jialabona
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/307002_jialabona

Install by copying the package folder contents into your Codex pets directory.
