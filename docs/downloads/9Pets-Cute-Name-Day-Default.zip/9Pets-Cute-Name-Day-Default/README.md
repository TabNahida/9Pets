# 9Pets-Cute-Name-Day-Default

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 311801.
Skin: Default.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_311801_mmr.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_311801_mmr
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a7_311801_mmr

Install by copying the package folder contents into your Codex pets directory.
