# 9Pets-Cute-Sputnik-Eek-Eek

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305502.
Skin: Eek, Eek!.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_305502_sptnk.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a0_305502_sptnk
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
