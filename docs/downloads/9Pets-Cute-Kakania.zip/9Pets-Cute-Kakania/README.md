# 9Pets-Cute-Kakania

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308001.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_308001_kkny.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a9_308001_kkny
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a9_308001_kakaniya

Install by copying the package folder contents into your Codex pets directory.
