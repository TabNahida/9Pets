# 9Pets-Cute-Fatutu-Fragments-of-An-Old-Dream

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310905.
Skin: Fragments of An Old Dream.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_310905_ttsz.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a7_310905_ttsz
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a7_310905_ttsz

Install by copying the package folder contents into your Codex pets directory.
