# 9Pets-Cute-Rubuska-The-Piper-s-Dream

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312502.
Skin: The Piper's Dream.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a1_312502_ysm.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a1_312502_ysm
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a1_312502_ysm

Install by copying the package folder contents into your Codex pets directory.
