# 9Pets-Cute-Moldir-Idyll-of-the-Luberon

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 312103.
Skin: Idyll of the Luberon.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_312103_mlde.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_312103_mlde
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a3_312103_mlde

Install by copying the package folder contents into your Codex pets directory.
