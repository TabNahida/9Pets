# 9Pets-Cute-Igor-Where-the-Banner-Points

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309202.
Skin: Where the Banner Points.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_309202_yge.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a3_309202_yge
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a3_309202_yge

Install by copying the package folder contents into your Codex pets directory.
