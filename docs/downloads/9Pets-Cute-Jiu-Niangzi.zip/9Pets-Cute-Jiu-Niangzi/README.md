# 9Pets-Cute-Jiu-Niangzi

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 308301.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_308301_qn.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a6_308301_qn
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a6_308301_quniang

Install by copying the package folder contents into your Codex pets directory.
