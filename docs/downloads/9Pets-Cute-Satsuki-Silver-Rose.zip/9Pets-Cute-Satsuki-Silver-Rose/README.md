# 9Pets-Cute-Satsuki-Silver-Rose

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303803.
Skin: Silver Rose.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_303803_wsy.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_303803_wsy
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a7_303803_wuseyue

Install by copying the package folder contents into your Codex pets directory.
