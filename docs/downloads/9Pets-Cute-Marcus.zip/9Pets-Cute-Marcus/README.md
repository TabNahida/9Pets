# 9Pets-Cute-Marcus

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 306501.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_306501_makusi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a7_306501_makusi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a7_306501_makusi

Install by copying the package folder contents into your Codex pets directory.
