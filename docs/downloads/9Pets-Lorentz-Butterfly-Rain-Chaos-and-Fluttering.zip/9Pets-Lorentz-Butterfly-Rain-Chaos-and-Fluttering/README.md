# 9Pets-Lorentz-Butterfly-Rain-Chaos-and-Fluttering

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 313902.
Skin: Rain, Chaos and Fluttering.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/313902.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a5_313902_llzhd
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a5_313902_llzhd

Install by copying the package folder contents into your Codex pets directory.
