# 9Pets-Cute-Desert-Flannel

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 307501.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_307501_shasirong.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_307501_shasirong
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v1a5_307501_shasirong

Install by copying the package folder contents into your Codex pets directory.
