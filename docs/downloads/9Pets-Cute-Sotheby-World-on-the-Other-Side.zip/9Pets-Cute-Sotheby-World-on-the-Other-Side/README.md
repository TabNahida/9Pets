# 9Pets-Cute-Sotheby-World-on-the-Other-Side

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 300902.
Skin: World on the Other Side.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300902_sufubi.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/300902_sufubi
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/300902_sufubi

Install by copying the package folder contents into your Codex pets directory.
