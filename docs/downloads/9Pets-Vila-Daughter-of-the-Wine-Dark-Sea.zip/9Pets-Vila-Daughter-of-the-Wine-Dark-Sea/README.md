# 9Pets-Vila-Daughter-of-the-Wine-Dark-Sea

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 308704.
Skin: Daughter of the Wine-Dark Sea.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/308704.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/s01_308704_wl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/s01_308704_wl

Install by copying the package folder contents into your Codex pets directory.
