# 9Pets-Cute-John-Titor

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 303601.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303601_yuehantituo.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303601_yuehantituo
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
