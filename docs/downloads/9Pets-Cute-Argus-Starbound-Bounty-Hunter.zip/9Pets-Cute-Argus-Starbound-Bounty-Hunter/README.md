# 9Pets-Cute-Argus-Starbound-Bounty-Hunter

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 309703.
Skin: Starbound Bounty Hunter.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_309703_aegs.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v2a7_309703_aegs
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v2a7_309703_aegs

Install by copying the package folder contents into your Codex pets directory.
