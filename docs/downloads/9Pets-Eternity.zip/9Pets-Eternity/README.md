# 9Pets-Eternity

Fan-made Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Live2D Cubism motion capture.
Official asset id: 305101.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/305101.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/305101_wennifuleide
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/305101_wennifuleide

Install by copying the package folder contents into your Codex pets directory.
