# 9Pets-Leilani

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official Spine motion capture.
Official asset id: 303501.
Source image: https://raw.githubusercontent.com/myssal/Reverse-1999-CN-Asset/master/singlebg/headicon_img/303501.png.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/303501_lilani
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
