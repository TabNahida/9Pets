# 9Pets-Cute-Brume-A-Wayward-Intermission

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 313502.
Skin: A Wayward Intermission.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_313502_hdl.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a2_313502_hdl
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a2_313502_hdl

Install by copying the package folder contents into your Codex pets directory.
