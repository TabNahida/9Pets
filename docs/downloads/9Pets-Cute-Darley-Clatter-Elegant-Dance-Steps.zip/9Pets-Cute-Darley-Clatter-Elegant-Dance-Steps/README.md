# 9Pets-Cute-Darley-Clatter-Elegant-Dance-Steps

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 305002.
Skin: Elegant Dance Steps.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_305003_dadadali.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v1a5_305003_dadadali
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
