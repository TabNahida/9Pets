# 9Pets-Cute-Flutterpage-Gently-Comes-the-Thawing-Breeze

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 310503.
Skin: Gently Comes the Thawing Breeze.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_310503_zxqe.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a0_310503_zxqe
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/v3a0_310503_zxqe

Install by copying the package folder contents into your Codex pets directory.
