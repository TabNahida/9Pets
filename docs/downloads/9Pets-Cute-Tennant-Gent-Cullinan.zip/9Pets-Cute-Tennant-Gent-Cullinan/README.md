# 9Pets-Cute-Tennant-Gent-Cullinan

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304302.
Skin: Gent Cullinan.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304302_tannante.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/304302_tannante
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/304302_tannante

Install by copying the package folder contents into your Codex pets directory.
