# 9Pets-Cute-Bette-A-Life-in-Frames

Official-sourced Codex pet package for Reverse: 1999.
Source mode: official-sourced.
Animation mode: Official chibi Spine motion capture.
Official asset id: 304504.
Skin: A Life in Frames.
Source image: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_304504_bd.
Spine assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/roles/v3a8_304504_bd
Live2D assets: https://github.com/myssal/Reverse-1999-CN-Asset/tree/master/live2d/roles/

Install by copying the package folder contents into your Codex pets directory.
